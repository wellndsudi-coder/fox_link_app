import 'dart:async';

import 'package:flutter/material.dart';
import 'package:get_it/get_it.dart';

import '../../../../core/session/tenant_session.dart';
import '../../../../core/database/tenant_firestore.dart';
import '../../domain/entities/availability.dart';
import '../../domain/usecases/save_availability.dart';
import '../../domain/usecases/get_professional_availability.dart';
import '../../domain/usecases/copy_week_availability_usecase.dart';
import '../widgets/working_hours_bar.dart';

class ProfessionalAvailabilityPage extends StatefulWidget {
  const ProfessionalAvailabilityPage({super.key});

  @override
  State<ProfessionalAvailabilityPage> createState() =>
      _ProfessionalAvailabilityPageState();
}

class _ProfessionalAvailabilityPageState
    extends State<ProfessionalAvailabilityPage> {

  final _session = GetIt.I<TenantSession>();
  final _firestore = GetIt.I<TenantFirestore>();
  final _saveUseCase = GetIt.I<SaveAvailability>();
  final _getUseCase = GetIt.I<GetProfessionalAvailability>();
  final _copyUseCase = GetIt.I<CopyWeekAvailabilityUseCase>();

  final List<String> weekLabels = [
    "SEG", "TER", "QUA", "QUI", "SEX", "SAB", "DOM"
  ];

  String? _professionalDocId;

  int selectedWeekday = 1;
  List<TimeRange> shifts = [];
  int slotIntervalMinutes = 0;

  Timer? _autoSaveTimer;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    await _resolveProfessionalId();
    await _loadAvailability();
  }

  Future<void> _resolveProfessionalId() async {
    final snapshot = await _firestore
        .collection('professionals')
        .where('email', isEqualTo: _session.email)
        .limit(1)
        .get();

    if (snapshot.docs.isNotEmpty) {
      _professionalDocId = snapshot.docs.first.id;
    }
  }

  Future<void> _loadAvailability() async {
    if (_professionalDocId == null) return;

    final all = await _getUseCase(_professionalDocId!);

    final existing =
    all.where((a) => a.weekday == selectedWeekday);

    if (existing.isNotEmpty) {
      final data = existing.first;

      setState(() {
        shifts = List.from(data.shifts);
        slotIntervalMinutes = data.slotIntervalMinutes;
      });
    } else {
      setState(() {
        shifts = [];
        slotIntervalMinutes = 0;
      });
    }
  }

  void _scheduleAutoSave() {
    _autoSaveTimer?.cancel();

    _autoSaveTimer = Timer(
      const Duration(milliseconds: 600),
          () async {
        if (_professionalDocId == null) return;

        final availability = Availability(
          id: '${_professionalDocId}_$selectedWeekday',
          professionalId: _professionalDocId!,
          weekday: selectedWeekday,
          isActive: true,
          shifts: shifts,
          slotIntervalMinutes: slotIntervalMinutes,
          breakTimes: const [],
        );

        await _saveUseCase(availability);
      },
    );
  }

  Future<void> _changeDay(int weekday) async {
    setState(() {
      selectedWeekday = weekday;
    });

    await _loadAvailability();
  }

  Future<void> _copyToWholeWeek() async {
    if (_professionalDocId == null) return;

    await _copyUseCase(
      professionalId: _professionalDocId!,
      sourceWeekday: selectedWeekday,
    );

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text("Copiado para toda a semana!"),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: const Color(0xFFF4F6FA),
      appBar: AppBar(
        title: const Text("Disponibilidade"),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [

            // 🔥 Calendário semanal
            Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: List.generate(7, (index) {
                  final weekday = index + 1;
                  final isSelected =
                      weekday == selectedWeekday;

                  return Expanded(
                    child: GestureDetector(
                      onTap: () => _changeDay(weekday),
                      child: Container(
                        margin: const EdgeInsets.symmetric(horizontal: 4),
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        decoration: BoxDecoration(
                          color: isSelected
                              ? Colors.blue
                              : Colors.grey.shade200,
                          borderRadius:
                          BorderRadius.circular(12),
                        ),
                        child: Center(
                          child: Text(
                            weekLabels[index],
                            style: TextStyle(
                              color: isSelected
                                  ? Colors.white
                                  : Colors.black87,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ),
                    ),
                  );
                }),
              ),
            ),

            Container(
              margin: const EdgeInsets.all(16),
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: const [
                  BoxShadow(
                    blurRadius: 12,
                    color: Colors.black12,
                  )
                ],
              ),
              child: Column(
                crossAxisAlignment:
                CrossAxisAlignment.start,
                children: [

                  Row(
                    mainAxisAlignment:
                    MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        "Turnos do dia",
                        style: TextStyle(
                          fontWeight: FontWeight.w600,
                          fontSize: 16,
                        ),
                      ),
                      TextButton(
                        onPressed: _copyToWholeWeek,
                        child: const Text(
                          "Copiar p/ semana",
                          style: TextStyle(
                              fontWeight: FontWeight.w600),
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 12),

                  WorkingHoursBar(
                    shifts: shifts,
                    onChanged: (updated) {
                      setState(() {
                        shifts = updated;
                      });

                      _scheduleAutoSave();
                    },
                  ),

                  const SizedBox(height: 24),

                  const Text(
                    "Intervalo entre clientes",
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 16,
                    ),
                  ),

                  Center(
                    child: Text(
                      "$slotIntervalMinutes min",
                      style: const TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                        color: Colors.blue,
                      ),
                    ),
                  ),

                  Slider(
                    value: slotIntervalMinutes.toDouble(),
                    min: 0,
                    max: 30,
                    divisions: 30,
                    onChanged: (value) {
                      setState(() {
                        slotIntervalMinutes =
                            value.round();
                      });

                      _scheduleAutoSave();
                    },
                  ),
                ],
              ),
            ),

            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }
}