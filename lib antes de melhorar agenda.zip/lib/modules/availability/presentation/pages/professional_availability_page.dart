import 'package:flutter/material.dart';
import 'package:get_it/get_it.dart';

import '../../../../core/session/tenant_session.dart';
import '../../../../core/database/tenant_firestore.dart';
import '../../domain/entities/availability.dart';
import '../../domain/usecases/save_availability.dart';
import '../../domain/usecases/get_professional_availability.dart';
import '../../domain/usecases/copy_week_availability_usecase.dart';
import 'monthly_availability_page.dart';

class ProfessionalAvailabilityPage extends StatefulWidget {
  const ProfessionalAvailabilityPage({super.key});

  @override
  State<ProfessionalAvailabilityPage> createState() =>
      _ProfessionalAvailabilityPageState();
}

class _ProfessionalAvailabilityPageState
    extends State<ProfessionalAvailabilityPage> {

  final _session = GetIt.I<TenantSession>();
  final _firestore = GetIt.I<TenantFirestore>();
  final _saveUseCase = GetIt.I<SaveAvailability>();
  final _getUseCase = GetIt.I<GetProfessionalAvailability>();
  final _copyUseCase = GetIt.I<CopyWeekAvailabilityUseCase>();

  final List<String> weekLabels = [
    "SEG", "TER", "QUA", "QUI", "SEX", "SAB", "DOM"
  ];

  String? _professionalDocId;

  int selectedWeekday = 1;
  bool isActive = true;

  List<TimeRange> shifts = [];

  int slotIntervalMinutes = 0;
  List<TimeRange> breakTimes = [];

  bool loading = false;

  double startSliderValue = 480; // 08:00
  double endSliderValue = 1020;  // 17:00

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    await _resolveProfessionalId();
    await _loadAvailability();
  }

  Future<void> _resolveProfessionalId() async {
    final snapshot = await _firestore
        .collection('professionals')
        .where('email', isEqualTo: _session.email)
        .limit(1)
        .get();

    if (snapshot.docs.isNotEmpty) {
      _professionalDocId = snapshot.docs.first.id;
    }
  }

  Future<void> _loadAvailability() async {
    if (_professionalDocId == null) return;

    final all = await _getUseCase(_professionalDocId!);

    final existing =
    all.where((a) => a.weekday == selectedWeekday);

    if (existing.isNotEmpty) {
      final data = existing.first;

      setState(() {
        shifts = List.from(data.shifts);
        slotIntervalMinutes = data.slotIntervalMinutes;
        breakTimes = List.from(data.breakTimes);

        if (shifts.isNotEmpty) {
          startSliderValue =
              shifts.first.startMinutes.toDouble();
          endSliderValue =
              shifts.first.endMinutes.toDouble();
        }
      });
    } else {
      setState(() {
        shifts = [];
        breakTimes = [];
      });
    }
  }

  Future<void> _changeDay(int weekday) async {
    setState(() {
      selectedWeekday = weekday;
    });
    await _loadAvailability();
  }

  void _defineShift() {
    final start = startSliderValue.toInt();
    final end = endSliderValue.toInt();

    if (end <= start) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Hora final deve ser maior que inicial."),
        ),
      );
      return;
    }

    setState(() {
      shifts = [
        TimeRange(
          startMinutes: start,
          endMinutes: end,
        )
      ];
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Turno definido!")),
    );
  }

  Future<void> _addBreakTime() async {
    if (shifts.isEmpty) return;

    final start = await showTimePicker(
      context: context,
      initialTime: const TimeOfDay(hour: 12, minute: 0),
    );
    if (start == null) return;

    final end = await showTimePicker(
      context: context,
      initialTime: const TimeOfDay(hour: 13, minute: 0),
    );
    if (end == null) return;

    final startMinutes = start.hour * 60 + start.minute;
    final endMinutes = end.hour * 60 + end.minute;

    setState(() {
      breakTimes.add(
        TimeRange(
          startMinutes: startMinutes,
          endMinutes: endMinutes,
        ),
      );
      breakTimes.sort(
              (a, b) => a.startMinutes.compareTo(b.startMinutes));
    });
  }

  Future<void> _save() async {
    if (_professionalDocId == null) return;

    final availability = Availability(
      id: '${_professionalDocId}_$selectedWeekday',
      professionalId: _professionalDocId!,
      weekday: selectedWeekday,
      isActive: true,
      shifts: shifts,
      slotIntervalMinutes: slotIntervalMinutes,
      breakTimes: breakTimes,
    );

    await _saveUseCase(availability);

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Disponibilidade salva!")),
    );
  }

  String _formatTime(int minutes) {
    final h = (minutes ~/ 60).toString().padLeft(2, '0');
    final m = (minutes % 60).toString().padLeft(2, '0');
    return "$h:$m";
  }

  @override
  Widget build(BuildContext context) {

    final currentShiftText = shifts.isEmpty
        ? "Nenhum turno definido"
        : "${_formatTime(shifts.first.startMinutes)} - ${_formatTime(shifts.first.endMinutes)}";

    return Scaffold(
      backgroundColor: const Color(0xFFF4F6FA),
      appBar: AppBar(
        title: const Text("Disponibilidade"),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [

            Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: List.generate(7, (index) {
                  final weekday = index + 1;
                  final isSelected =
                      weekday == selectedWeekday;

                  return Expanded(
                    child: GestureDetector(
                      onTap: () => _changeDay(weekday),
                      child: Container(
                        margin:
                        const EdgeInsets.symmetric(horizontal: 4),
                        padding:
                        const EdgeInsets.symmetric(vertical: 10),
                        decoration: BoxDecoration(
                          color: isSelected
                              ? Colors.blue
                              : Colors.grey.shade200,
                          borderRadius:
                          BorderRadius.circular(12),
                        ),
                        child: Center(
                          child: Text(
                            weekLabels[index],
                            style: TextStyle(
                              color: isSelected
                                  ? Colors.white
                                  : Colors.black87,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ),
                    ),
                  );
                }),
              ),
            ),

            Container(
              margin: const EdgeInsets.all(16),
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: const [
                  BoxShadow(
                    blurRadius: 12,
                    color: Colors.black12,
                  )
                ],
              ),
              child: Column(
                crossAxisAlignment:
                CrossAxisAlignment.start,
                children: [

                  const Text(
                    "Turno do dia",
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 16,
                    ),
                  ),

                  const SizedBox(height: 12),

                  Text("Hora inicial: ${_formatTime(startSliderValue.toInt())}"),
                  Slider(
                    value: startSliderValue,
                    min: 0,
                    max: 1425,
                    divisions: 95,
                    onChanged: (value) {
                      setState(() {
                        startSliderValue = value;
                      });
                    },
                  ),

                  Text("Hora final: ${_formatTime(endSliderValue.toInt())}"),
                  Slider(
                    value: endSliderValue,
                    min: 15,
                    max: 1440,
                    divisions: 95,
                    onChanged: (value) {
                      setState(() {
                        endSliderValue = value;
                      });
                    },
                  ),

                  const SizedBox(height: 10),

                  ElevatedButton(
                    onPressed: _defineShift,
                    child: const Text("Definir turno"),
                  ),

                  const SizedBox(height: 10),

                  Text(
                    "Turno atual: $currentShiftText",
                    style: const TextStyle(
                      fontWeight: FontWeight.w600,
                      color: Colors.green,
                    ),
                  ),

                  const SizedBox(height: 20),

                  const Text(
                    "Intervalo entre clientes",
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 16,
                    ),
                  ),

                  Center(
                    child: Text(
                      "$slotIntervalMinutes min",
                      style: const TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                        color: Colors.blue,
                      ),
                    ),
                  ),

                  Slider(
                    value: slotIntervalMinutes.toDouble(),
                    min: 0,
                    max: 15,
                    divisions: 15,
                    onChanged: (value) {
                      setState(() {
                        slotIntervalMinutes =
                            value.round();
                      });
                    },
                  ),

                  const SizedBox(height: 20),

                  Row(
                    mainAxisAlignment:
                    MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        "Intervalos de refeição",
                        style: TextStyle(
                          fontWeight: FontWeight.w600,
                          fontSize: 16,
                        ),
                      ),
                      TextButton.icon(
                        onPressed: _addBreakTime,
                        icon: const Icon(Icons.add),
                        label:
                        const Text("Adicionar"),
                      ),
                    ],
                  ),

                  if (breakTimes.isEmpty)
                    const Text(
                      "Nenhum intervalo definido",
                      style: TextStyle(color: Colors.grey),
                    ),

                  ...breakTimes.map((breakTime) {
                    return ListTile(
                      title: Text(
                        "${_formatTime(breakTime.startMinutes)} - ${_formatTime(breakTime.endMinutes)}",
                      ),
                    );
                  }),
                ],
              ),
            ),

            ElevatedButton(
              onPressed: _save,
              child:
              const Text("Salvar disponibilidade"),
            ),

            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }
}